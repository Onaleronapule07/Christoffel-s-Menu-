import { Course } from '../types';

export const COLORS = {
    primary: '#00C4D1',
    primaryDark: '#00808A',
    success: '#34C759',
    danger: '#D32F2F',
    white: '#ffffff',
    black: '#000000',
    textDark: '#222222',
    textMuted: '#777777',
    inputBackground: '#D9D9D9',
    cardBackground: '#F2F2F2',
};

export const COURSES: Course[] = ['Starter', 'Main Course', 'Dessert'];