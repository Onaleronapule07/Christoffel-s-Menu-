import React, { useMemo, useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import AppButton from '../../../../../../AppButton';
import CourseFilter from '../../CourseFilter';
import EmptyState from '../../EmptyState';
import MenuItemCard from '../../../../MenuItemCard';
import SearchBar from '../../../SearchBar';
import { COLORS } from '../../../../../../../../../theme';
import { useMenu } from '../../../../../../../MenuContext';
import { CourseFilterValue, MenuItem, RootStackParamList } from '../../../../../../../../../../types';
import { filterMenuItems } from '../../menuUtils';

type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

export default function HomeScreen({ navigation }: Props) {
    const { menuItems, deleteMenuItem } = useMenu();
    const [searchText, setSearchText] = useState('');
    const [courseFilter, setCourseFilter] = useState<CourseFilterValue>('All');

    const visibleItems = useMemo(
        () => filterMenuItems(menuItems, searchText, courseFilter),
        [menuItems, searchText, courseFilter],
    );

    const isFiltering = searchText.trim() !== '' || courseFilter !== 'All';

    const clearSearchAndFilter = () => {
        setSearchText('');
        setCourseFilter('All');
    };

    const handleEdit = (item: MenuItem) => {
        navigation.navigate('MenuForm', { itemId: item.id });
    };

    const handleDelete = (item: MenuItem) => {
        Alert.alert('Delete Menu Item', `Are you sure you want to delete "${item.name}"?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Delete', style: 'destructive', onPress: () => deleteMenuItem(item.id) },
        ]);
    };

    return (
        <View style={styles.container}>
            <Text style={styles.heading}>
                {isFiltering
                    ? `Showing ${visibleItems.length} of ${menuItems.length} items`
                    : `Menu Items (${menuItems.length})`}
            </Text>

            <SearchBar value={searchText} onChangeText={setSearchText} />
            <CourseFilter selected={courseFilter} onSelect={setCourseFilter} />

            {isFiltering && (
                <AppButton
                    title="Clear Search & Filter"
                    variant="outline"
                    style={styles.clearButton}
                    onPress={clearSearchAndFilter}
                />
            )}

            <FlatList
                data={visibleItems}
                keyExtractor={(item: MenuItem) => item.id}
                renderItem={({ item }) => (
                    <MenuItemCard item={item} onEdit={handleEdit} onDelete={handleDelete} />
                )}
                contentContainerStyle={styles.listContent}
                keyboardShouldPersistTaps="handled"
                ListEmptyComponent={
                    menuItems.length === 0 ? (
                        <EmptyState
                            title="No dishes yet"
                            message={'Tap "+ Add New Menu Item" below to add your first dish.'}
                        />
                    ) : (
                        <EmptyState
                            title="No matching dishes"
                            message="Try a different name or clear the search and filter."
                        />
                    )
                }
            />

            <View style={styles.footer}>
                <AppButton
                    title="+ Add New Menu Item"
                    onPress={() => navigation.navigate('MenuForm')}
                />
                <AppButton
                    title="View Menu Statistics"
                    variant="secondary"
                    style={styles.statsButton}
                    onPress={() => navigation.navigate('Statistics')}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
        paddingHorizontal: 16,
        paddingTop: 16,
    },
    heading: { fontSize: 20, fontWeight: 'bold', color: COLORS.textDark, marginBottom: 12 },
    clearButton: { marginBottom: 10, paddingVertical: 10 },
    listContent: { flexGrow: 1, paddingBottom: 8 },
    footer: { paddingVertical: 12 },
    statsButton: { marginTop: 10 },
});