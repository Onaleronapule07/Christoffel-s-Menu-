import React from 'react';
import { StyleSheet, TextInput } from 'react-native';
import { COLORS } from '../../../../../../theme';

interface Props {
    value: string;
    onChangeText: (text: string) => void;
}

export default function SearchBar({ value, onChangeText }: Props) {
    return (
        <TextInput
            style={styles.input}
            placeholder="Search dishes by name"
            value={value}
            onChangeText={onChangeText}
            autoCorrect={false}
            returnKeyType="search"
            accessibilityLabel="Search menu items by name"
        />
    );
}

const styles = StyleSheet.create({
    input: {
        backgroundColor: COLORS.inputBackground,
        borderRadius: 6,
        paddingHorizontal: 12,
        paddingVertical: 10,
        fontSize: 16,
        marginBottom: 10,
    },
});