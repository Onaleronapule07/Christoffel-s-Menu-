import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { COLORS, COURSES } from '../../../../../../../theme';
import { CourseFilterValue } from '../../../../../../../../types';

interface Props {
    selected: CourseFilterValue;
    onSelect: (course: CourseFilterValue) => void;
}

const OPTIONS: CourseFilterValue[] = ['All', ...COURSES];

export default function CourseFilter({ selected, onSelect }: Props) {
    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.row}
            keyboardShouldPersistTaps="handled"
        >
            {OPTIONS.map((option) => {
                const active = option === selected;
                return (
                    <TouchableOpacity
                        key={option}
                        style={[styles.chip, active && styles.chipActive]}
                        onPress={() => onSelect(option)}
                        accessibilityRole="button"
                        accessibilityState={{ selected: active }}
                    >
                        <Text style={[styles.chipText, active && styles.chipTextActive]}>
                            {option}
                        </Text>
                    </TouchableOpacity>
                );
            })}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    row: { flexGrow: 0, marginBottom: 10 },
    chip: {
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 20,
        backgroundColor: COLORS.cardBackground,
        marginRight: 8,
        borderWidth: 1,
        borderColor: COLORS.primaryDark,
    },
    chipActive: { backgroundColor: COLORS.primaryDark },
    chipText: { fontSize: 15, color: COLORS.primaryDark, fontWeight: '600' },
    chipTextActive: { color: COLORS.white },
});