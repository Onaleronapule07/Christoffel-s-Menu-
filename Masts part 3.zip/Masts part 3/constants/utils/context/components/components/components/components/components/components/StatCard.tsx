import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../../../../../../../../theme';

interface Props {
    label: string;
    value: string | number;
}

export default function StatCard({ label, value }: Props) {
    return (
        <View style={styles.card}>
            <Text style={styles.value}>{value}</Text>
            <Text style={styles.label}>{label}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    card: {
        flex: 1,
        backgroundColor: COLORS.cardBackground,
        borderRadius: 8,
        padding: 16,
        alignItems: 'center',
    },
    value: { fontSize: 28, fontWeight: 'bold', color: COLORS.primaryDark },
    label: { fontSize: 15, color: '#444444', marginTop: 4, textAlign: 'center' },
});