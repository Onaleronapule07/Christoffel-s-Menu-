import React from 'react';
import { StyleSheet, Text, TextInput, TextInputProps } from 'react-native';
import { COLORS } from '../../../../theme';

interface Props extends TextInputProps {
    label: string;
    error?: string;
}

export default function FormField({ label, error, style, ...inputProps }: Props) {
    return (
        <>
            <Text style={styles.label}>{label}</Text>
            <TextInput
                style={[styles.input, !!error && styles.inputError, style]}
                accessibilityLabel={label}
                {...inputProps}
            />
            {!!error && <Text style={styles.errorText}>{error}</Text>}
        </>
    );
}

const styles = StyleSheet.create({
    label: {
        fontSize: 18,
        fontWeight: 'bold',
        color: COLORS.black,
        marginTop: 16,
        marginBottom: 6,
    },
    input: {
        backgroundColor: COLORS.inputBackground,
        borderRadius: 6,
        paddingHorizontal: 12,
        paddingVertical: 12,
        fontSize: 16,
        borderWidth: 1,
        borderColor: 'transparent',
    },
    inputError: { borderColor: COLORS.danger },
    errorText: { color: COLORS.danger, fontSize: 14, marginTop: 4 },
});