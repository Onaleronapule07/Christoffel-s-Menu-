export type Course = 'Starter' | 'Main Course' | 'Dessert';

export type CourseFilterValue = Course | 'All';

export interface MenuItem {
    id: string;
    name: string;
    description: string;
    course: Course;
    price: number;
}

export type MenuItemInput = Omit<MenuItem, 'id'>;

export interface MenuFormValues {
    name: string;
    description: string;
    course: Course | '';
    price: string;
}

export interface MenuFormErrors {
    name?: string;
    description?: string;
    course?: string;
    price?: string;
}

export interface MenuStatistics {
    totalItems: number;
    averagePrice: number;
    countByCourse: Record<Course, number>;
}

export type RootStackParamList = {
    Home: undefined;
    MenuForm: { itemId?: string } | undefined;
    Statistics: undefined;
};