import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { MenuProvider } from './context/MenuContext';
import { COLORS } from './constants/theme';
import HomeScreen from '../../HomeSreen';
import MenuFormScreen from '../MenuFormScreen';
import StatisticsScreen from './StatisticsScreen';
import { RootStackParamList } from '../../../../../../../../../../../../types';

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
    return (
        <MenuProvider>
            <NavigationContainer>
                <Stack.Navigator
                    initialRouteName="Home"
                    screenOptions={{
                        headerStyle: { backgroundColor: COLORS.primary },
                        headerTintColor: COLORS.white,
                        headerTitleStyle: { fontWeight: 'bold', fontSize: 22 },
                    }}
                >
                    <Stack.Screen
                        name="Home"
                        component={HomeScreen}
                        options={{ title: "Christoffel's Menu" }}
                    />
                    <Stack.Screen
                        name="MenuForm"
                        component={MenuFormScreen}
                        options={({ route }) => ({
                            title: route.params?.itemId ? 'Edit Menu Item' : 'Add Menu Item',
                        })}
                    />
                    <Stack.Screen
                        name="Statistics"
                        component={StatisticsScreen}
                        options={{ title: 'Menu Statistics' }}
                    />
                </Stack.Navigator>
            </NavigationContainer>
        </MenuProvider>
    );
}