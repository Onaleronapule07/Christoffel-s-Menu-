import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../../../../../theme';
import { MenuItem } from '../../../../../../types';
import { formatPrice } from '../../../../meuUtils';
import AppButton from '../../AppButton';

interface Props {
    item: MenuItem;
    onEdit: (item: MenuItem) => void;
    onDelete: (item: MenuItem) => void;
}

export default function MenuItemCard({ item, onEdit, onDelete }: Props) {
    return (
        <View style={styles.card}>
            <View style={styles.cardTop}>
                <Text style={styles.dishName}>{item.name}</Text>
                <Text style={styles.price}>{formatPrice(item.price)}</Text>
            </View>
            <Text style={styles.course}>{item.course}</Text>
            <Text style={styles.description}>{item.description}</Text>

            <View style={styles.actions}>
                <AppButton
                    title="Edit"
                    variant="secondary"
                    style={styles.actionButton}
                    onPress={() => onEdit(item)}
                />
                <AppButton
                    title="Delete"
                    variant="danger"
                    style={styles.actionButton}
                    onPress={() => onDelete(item)}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    card: {
        backgroundColor: COLORS.cardBackground,
        borderRadius: 8,
        padding: 14,
        marginBottom: 12,
    },
    cardTop: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    dishName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: COLORS.black,
        flex: 1,
        marginRight: 8,
    },
    price: { fontSize: 18, fontWeight: 'bold', color: COLORS.black },
    course: { fontSize: 14, color: COLORS.primaryDark, fontWeight: '600', marginTop: 4 },
    description: { fontSize: 15, color: '#444444', marginTop: 6 },
    actions: { flexDirection: 'row', marginTop: 12, gap: 10 },
    actionButton: { flex: 1, paddingVertical: 10 },
});