import React from 'react';
import { StyleProp, StyleSheet, Text, TouchableOpacity, ViewStyle } from 'react-native';
import { COLORS } from '../../../theme';

type Variant = 'primary' | 'secondary' | 'danger' | 'outline';

interface Props {
    title: string;
    onPress: () => void;
    variant?: Variant;
    style?: StyleProp<ViewStyle>;
}

export default function AppButton({ title, onPress, variant = 'primary', style }: Props) {
    return (
        <TouchableOpacity
            style={[styles.button, styles[variant], style]}
            onPress={onPress}
            accessibilityRole="button"
            accessibilityLabel={title}
        >
            <Text style={[styles.text, variant === 'outline' && styles.outlineText]}>{title}</Text>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    button: {
        paddingVertical: 14,
        paddingHorizontal: 16,
        borderRadius: 8,
        alignItems: 'center',
    },
    primary: { backgroundColor: COLORS.success },
    secondary: { backgroundColor: COLORS.primaryDark },
    danger: { backgroundColor: COLORS.danger },
    outline: {
        backgroundColor: COLORS.white,
        borderWidth: 1.5,
        borderColor: COLORS.primaryDark,
    },
    text: { color: COLORS.white, fontSize: 17, fontWeight: 'bold' },
    outlineText: { color: COLORS.primaryDark },
});