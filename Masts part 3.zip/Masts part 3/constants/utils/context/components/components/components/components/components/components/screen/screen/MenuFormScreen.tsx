import React, { useEffect, useState } from 'react';
import {
    Alert,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import AppButton from '../../../../../../../AppButton';
import FormField from '../../../../../../FormField';
import { COLORS, COURSES } from '../../../../../../../../../../theme';
import { useMenu } from '../../../../../../../../MenuContext';
import { MenuFormErrors, MenuFormValues, RootStackParamList } from '../../../../../../../../../../../types';
import { parsePrice, validateMenuForm } from '../utils/menuUtils';

type Props = NativeStackScreenProps<RootStackParamList, 'MenuForm'>;

const EMPTY_FORM: MenuFormValues = { name: '', description: '', course: '', price: '' };

export default function MenuFormScreen({ navigation, route }: Props) {
    const { addMenuItem, updateMenuItem, getMenuItemById } = useMenu();

    const itemId = route.params?.itemId;
    const existingItem = itemId ? getMenuItemById(itemId) : undefined;
    const isEditing = existingItem !== undefined;

    const [values, setValues] = useState<MenuFormValues>(EMPTY_FORM);
    const [errors, setErrors] = useState<MenuFormErrors>({});

    // Pre-fill the form when editing an existing dish.
    useEffect(() => {
        if (existingItem) {
            setValues({
                name: existingItem.name,
                description: existingItem.description,
                course: existingItem.course,
                price: existingItem.price.toString(),
            });
        }
        // Only run when the screen opens for a different item.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [itemId]);

    const updateField = <K extends keyof MenuFormValues>(field: K, value: MenuFormValues[K]) => {
        setValues((previous) => ({ ...previous, [field]: value }));
        // Clear the error for a field as soon as the user starts fixing it.
        setErrors((previous) => ({ ...previous, [field]: undefined }));
    };

    const handleSave = () => {
        const validationErrors = validateMenuForm(values);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) {
            return;
        }

        const itemData = {
            name: values.name.trim(),
            description: values.description.trim(),
            course: values.course as MenuFormValues['course'] & string,
            price: parsePrice(values.price),
        };

        if (isEditing && itemId) {
            updateMenuItem(itemId, itemData as Parameters<typeof updateMenuItem>[1]);
        } else {
            addMenuItem(itemData as Parameters<typeof addMenuItem>[0]);
        }

        Alert.alert(
            'Success',
            `"${itemData.name}" was ${isEditing ? 'updated' : 'added to the menu'}.`,
            [{ text: 'OK', onPress: () => navigation.goBack() }],
        );
    };

    return (
        <KeyboardAvoidingView
            style={styles.flex}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <ScrollView
                style={styles.container}
                contentContainerStyle={styles.content}
                keyboardShouldPersistTaps="handled"
            >
                <FormField
                    label="Dish Name"
                    placeholder="e.g. Bobotie"
                    value={values.name}
                    onChangeText={(text) => updateField('name', text)}
                    error={errors.name}
                />

                <FormField
                    label="Dish Description"
                    placeholder="e.g. A traditional South African dish made with spiced mince bake"
                    value={values.description}
                    onChangeText={(text) => updateField('description', text)}
                    error={errors.description}
                    style={styles.multiline}
                    multiline
                    numberOfLines={3}
                    textAlignVertical="top"
                />

                <Text style={styles.label}>Course</Text>
                <View style={[styles.pickerBox, !!errors.course && styles.pickerError]}>
                    <Picker
                        selectedValue={values.course}
                        onValueChange={(value: string) =>
                            updateField('course', value as MenuFormValues['course'])
                        }
                    >
                        <Picker.Item label="Select a course (Starter / Main Course / Dessert)" value="" />
                        {COURSES.map((course) => (
                            <Picker.Item key={course} label={course} value={course} />
                        ))}
                    </Picker>
                </View>
                {!!errors.course && <Text style={styles.errorText}>{errors.course}</Text>}

                <FormField
                    label="Price (R)"
                    placeholder="e.g. 145.00"
                    value={values.price}
                    onChangeText={(text) => updateField('price', text)}
                    error={errors.price}
                    keyboardType="decimal-pad"
                />

                <AppButton
                    title={isEditing ? 'Update Menu Item' : 'Save Menu Item'}
                    onPress={handleSave}
                    style={styles.saveButton}
                />
                <AppButton
                    title="Cancel"
                    variant="outline"
                    onPress={() => navigation.goBack()}
                    style={styles.cancelButton}
                />
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    flex: { flex: 1 },
    container: { flex: 1, backgroundColor: COLORS.white },
    content: { padding: 16, paddingBottom: 40 },
    label: {
        fontSize: 18,
        fontWeight: 'bold',
        color: COLORS.black,
        marginTop: 16,
        marginBottom: 6,
    },
    multiline: { height: 90 },
    pickerBox: {
        backgroundColor: COLORS.inputBackground,
        borderRadius: 6,
        borderWidth: 1,
        borderColor: 'transparent',
    },
    pickerError: { borderColor: COLORS.danger },
    errorText: { color: COLORS.danger, fontSize: 14, marginTop: 4 },
    saveButton: { marginTop: 30 },
    cancelButton: { marginTop: 12 },
});