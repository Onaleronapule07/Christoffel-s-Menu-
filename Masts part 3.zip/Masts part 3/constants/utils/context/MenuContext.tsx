import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { MenuItem, MenuItemInput } from '../../../types';

interface MenuContextValue {
    menuItems: MenuItem[];
    addMenuItem: (item: MenuItemInput) => void;
    updateMenuItem: (id: string, item: MenuItemInput) => void;
    deleteMenuItem: (id: string) => void;
    getMenuItemById: (id: string) => MenuItem | undefined;
}

const MenuContext = createContext<MenuContextValue | undefined>(undefined);

export function MenuProvider({ children }: { children: React.ReactNode }) {
    const [menuItems, setMenuItems] = useState<MenuItem[]>([]);

    const addMenuItem = useCallback((item: MenuItemInput) => {
        const newItem: MenuItem = { ...item, id: Date.now().toString() };
        setMenuItems((previous) => [newItem, ...previous]);
    }, []);

    const updateMenuItem = useCallback((id: string, item: MenuItemInput) => {
        setMenuItems((previous) =>
            previous.map((existing) => (existing.id === id ? { ...item, id } : existing)),
        );
    }, []);

    const deleteMenuItem = useCallback((id: string) => {
        setMenuItems((previous) => previous.filter((existing) => existing.id !== id));
    }, []);

    const getMenuItemById = useCallback(
        (id: string) => menuItems.find((item) => item.id === id),
        [menuItems],
    );

    const value = useMemo(
        () => ({ menuItems, addMenuItem, updateMenuItem, deleteMenuItem, getMenuItemById }),
        [menuItems, addMenuItem, updateMenuItem, deleteMenuItem, getMenuItemById],
    );

    return <MenuContext.Provider value={value}>{children}</MenuContext.Provider>;
}

export function useMenu(): MenuContextValue {
    const context = useContext(MenuContext);
    if (!context) {
        throw new Error('useMenu must be used inside a MenuProvider.');
    }
    return context;
}