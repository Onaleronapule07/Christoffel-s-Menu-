import React, { useMemo } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import EmptyState from '../components/EmptyState';
import StatCard from '../../../StatCard';
import { COLORS, COURSES } from '../../../../../../../../../../../theme';
import { useMenu } from '../../../../../../../../../MenuContext';
import { RootStackParamList } from '../../../../../../../../../../../../types';
import { calculateStatistics, formatPrice } from '../utils/menuUtils';

type Props = NativeStackScreenProps<RootStackParamList, 'Statistics'>;

export default function StatisticsScreen(_props: Props) {
    const { menuItems } = useMenu();
    const stats = useMemo(() => calculateStatistics(menuItems), [menuItems]);

    if (stats.totalItems === 0) {
        return (
            <View style={styles.container}>
                <EmptyState
                    title="No statistics yet"
                    message="Add some dishes to see an overview of your menu."
                />
            </View>
        );
    }

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.content}>
            <Text style={styles.heading}>Menu Overview</Text>

            <View style={styles.row}>
                <StatCard label="Total Menu Items" value={stats.totalItems} />
                <View style={styles.gap} />
                <StatCard label="Average Price" value={formatPrice(stats.averagePrice)} />
            </View>

            <Text style={styles.heading}>Items per Course</Text>
            {COURSES.map((course) => (
                <View key={course} style={styles.courseRow}>
                    <Text style={styles.courseName}>{course}</Text>
                    <Text style={styles.courseCount}>{stats.countByCourse[course]}</Text>
                </View>
            ))}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.white },
    content: { padding: 16 },
    heading: {
        fontSize: 20,
        fontWeight: 'bold',
        color: COLORS.textDark,
        marginTop: 8,
        marginBottom: 12,
    },
    row: { flexDirection: 'row', marginBottom: 16 },
    gap: { width: 12 },
    courseRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: COLORS.cardBackground,
        borderRadius: 8,
        padding: 16,
        marginBottom: 10,
    },
    courseName: { fontSize: 18, color: COLORS.black },
    courseCount: { fontSize: 18, fontWeight: 'bold', color: COLORS.primaryDark },
});