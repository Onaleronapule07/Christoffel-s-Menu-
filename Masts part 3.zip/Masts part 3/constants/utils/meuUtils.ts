import { COURSES } from '../theme';
import {
    CourseFilterValue,
    MenuFormErrors,
    MenuFormValues,
    MenuItem,
    MenuStatistics,
} from '../types';

export const formatPrice = (price: number): string => `R${price.toFixed(2)}`;

// Accepts "145.50" and "145,50" (comma decimals are common in South Africa).
export const parsePrice = (value: string): number =>
    Number(value.trim().replace(',', '.'));

export const filterMenuItems = (
    items: MenuItem[],
    searchText: string,
    course: CourseFilterValue,
): MenuItem[] => {
    const query = searchText.trim().toLowerCase();

    return items.filter((item) => {
        const matchesCourse = course === 'All' || item.course === course;
        const matchesSearch = query === '' || item.name.toLowerCase().includes(query);
        return matchesCourse && matchesSearch;
    });
};

export const calculateStatistics = (items: MenuItem[]): MenuStatistics => {
    const totalItems = items.length;
    const totalPrice = items.reduce((sum, item) => sum + item.price, 0);

    const countByCourse = COURSES.reduce(
        (counts, course) => ({
            ...counts,
            [course]: items.filter((item) => item.course === course).length,
        }),
        {} as MenuStatistics['countByCourse'],
    );

    return {
        totalItems,
        averagePrice: totalItems === 0 ? 0 : totalPrice / totalItems,
        countByCourse,
    };
};

export const validateMenuForm = (values: MenuFormValues): MenuFormErrors => {
    const errors: MenuFormErrors = {};

    if (values.name.trim() === '') {
        errors.name = 'Please enter the dish name.';
    } else if (values.name.trim().length < 2) {
        errors.name = 'The dish name must be at least 2 characters.';
    }

    if (values.description.trim() === '') {
        errors.description = 'Please enter the dish description.';
    }

    if (values.course === '') {
        errors.course = 'Please select a course.';
    }

    if (values.price.trim() === '') {
        errors.price = 'Please enter the dish price.';
    } else {
        const priceNumber = parsePrice(values.price);
        if (isNaN(priceNumber) || priceNumber <= 0) {
            errors.price = 'Please enter a valid number greater than 0.';
        }
    }

    return errors;
};